/*
 * 
 */
package client;

import clientui.OvenUI;

/*
 *File Title: OvenClient.java							
 *
 * @author:Karolina Laptas, x14446332
 *
 * @reference sample by Dominic Carr https://moodle.ncirl.ie/course/view.php?id=1473	
 */
public class OvenClient extends Client {

    private final String WARM = "Warm";
    private boolean isWarming = false;

    /**
     * Bed Client Constructor.
     */
    public OvenClient() {
        super();
        serviceType = "_oven._udp.local.";
        ui = new OvenUI(this);
        name = "Oven";
    }

    /**
     * sends a message to warm the bed.
     */
    public void warm() {
        if (!isWarming) {
            String a = sendMessage(WARM);
            if (a.equals(OK)) {
                isWarming = true;
                ui.updateArea("Oven is PreHeating");
            }
        } else {
            ui.updateArea("Oven already PreHeated");
        }
    }

    public void power_off() {
        System.out.println("Oven is turned Off");
    }

    public void power_on() {
        System.out.println("Oven is turned On");
    }
    
    @Override
    public void updatePoll(String msg) {
        if (msg.equals("Oven is 100% heated.")) {
            isWarming = false;
        }
    }

    @Override
    public void disable() {
        super.disable();
        ui = new OvenUI(this);
        isWarming = false;
    }

   
}
