package clientui;

public class UIConstants {

    public static final int UIWIDTH = 550;
    public static final int UIHEIGHT = 600;
    public static final int COMPONENTWIDTH = 520;
    public static final int CONTROLY = 425;
}
